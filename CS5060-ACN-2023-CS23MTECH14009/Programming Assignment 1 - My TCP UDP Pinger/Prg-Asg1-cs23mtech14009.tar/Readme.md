### Programming Setup to Run UDP 

For UDPPingerServer and UDPPingerClient

Run Python3 UDPPingerServer.py on 1st Container
Run Python3 UDPPingerClient.py on 2nd Container

For UDPPingerClient.py and UDPPingerModifiedServer

Run Python3 UDPPingeModifiedServer.py on 1st Container
Run Python3 UDPPingerClient.py on 2nd Container

To incure loss 
tc qdisc add dev th0 root netem delay 33%


To delete the netem Command execution
tc qdisc change dev th0 root netem delay 33%

To Change 
tc qdisc change dev th0 root netem delay 33%


### Programming Setup to Run UDP 

For UDPPingerServer and UDPPingerClient

Run Python3 UDPPingerServer.py on 1st Container
Run Python3 UDPPingerClient.py on 2nd Container

For UDPPingerClient.py and UDPPingerModifiedServer

Run Python3 UDPPingeModifiedServer.py on 1st Container
Run Python3 UDPPingerClient.py on 2nd Container

To incure loss 
tc qdisc add dev th0 root netem delay 33%


To delete the netem Command execution
tc qdisc change dev th0 root netem delay 33%

To Change 
tc qdisc change dev th0 root netem delay 33%


### Programming Setup to Run UDP 

For UDPPingerServer and UDPPingerClient

Run Python3 UDPPingerServer.py on 1st Container
Run Python3 UDPPingerClient.py on 2nd Container

For UDPPingerClient.py and UDPPingerModifiedServer

Run Python3 UDPPingeModifiedServer.py on 1st Container
Run Python3 UDPPingerClient.py on 2nd Container

To incure loss 
tc qdisc add dev th0 root netem delay 33%


To delete the netem Command execution
tc qdisc change dev th0 root netem delay 33%

To Change 
tc qdisc change dev th0 root netem delay 33%




### TCP PINGER SERVER AND TCP PINGER CLIENT 

Run Python3 TCPPingerServer.py on 1st Container

Run Python3 TCPPingerClient.py on 2nd Container



### TCP PINGER MODIFIED SERVER AND TCP PINGER CLIENT 

Run Python3 TCPPingerModifiedServer.py on 1st Container

Run Python3 TCPPingerModifiedClient.py on 2nd Container



### TCP PINGER CONCURRENT SERVER AND TCP PINGER CLIENT 

Run Python3 TCPPingerModifiedConcurrentServer.py on 1st Container

Run Python3 TCPPingerModifiedConcurrentClient.py on 2nd Container

Run Python3 TCPPingerModifiedConcurrentClient.py on 3nd Container
