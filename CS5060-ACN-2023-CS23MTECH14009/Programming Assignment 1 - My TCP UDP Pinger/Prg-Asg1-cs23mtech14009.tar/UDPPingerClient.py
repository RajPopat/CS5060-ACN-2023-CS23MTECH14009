import socket
import time


# User define Function to connect the server 
def connect_to_server(destination_ip,destination_port):

  # Create a UDP socket
  client_socket=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
  # Wait for packet for 1 sec only
  client_socket.settimeout(1.0)

  server_address=(destination_ip,destination_port)
  # List to store a tuple of packet number and it's RTT
  list_of_time=[]
  try:
    # Connect the socket to the server's address and port
    client_socket.connect(server_address)
    # Take input from user of number of packets
    n = int(input("Enter the number of packets to send: "))
    send_packets(client_socket,server_address,list_of_time,n)
    # Because we got RTT time for only those packets which were not lost
    num_packet_loss = n-len(list_of_time)
    if list_of_time!=[]:
        print('Number of packet loss is: ' + str(num_packet_loss))
        print('Packet loss rate is: '+str((num_packet_loss/n)*100))
        print('Maximum RTT is: '+str(max(list_of_time)))
        print('Minimum RTT is: '+str(min(list_of_time)))
        print('Avg of RRT is: '+str(sum(list_of_time)/n))
    else:
        print('All packets are lost')
        client_socket.close()
  
  except Exception as e:
      print('Error: ',e)
  finally:
      client_socket.close()

def send_packets(client_socket,server_address,list_of_time,n):


  for i in range(1,n+1):

    # Store the time before sending    
    start_time = time.time()

    # Message formate is 'ping sequence_number time stemp'
    message='ping '+str(i)+' '+str(start_time)

    # Send the message to the server here we have to give server addrsss
    client_socket.sendto(message.encode(),server_address)

    try:
      # If you got response within 1 sec else it will go into except
      rmessage = client_socket.recvfrom(1025)[0]
      # Store the time after reply
      end_time=time.time()
      print("Server response:", rmessage.decode())
      print('RTT time for the packet is '+ str(end_time-start_time))
      list_of_time.append(end_time-start_time)


    except socket.timeout:
      print('Request timed out')






def main():
   connect_to_server(destination_ip='172.31.0.3',destination_port=5001)

if __name__ == "__main__":
  main()
