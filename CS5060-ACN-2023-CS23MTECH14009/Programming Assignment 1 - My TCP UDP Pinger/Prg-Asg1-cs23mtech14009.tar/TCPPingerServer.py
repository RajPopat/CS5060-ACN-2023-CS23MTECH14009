import socket
import random

def start_server(hostname,port_number):
    
    try:
        # Create a TCP socket
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
        # Bind the socket to a specific address and port
        server_address = (hostname,port_number)
        server_socket.bind(server_address)
    
        # Listen for incoming connections
        server_socket.listen(5)
        print("Server is listening for incoming connections...")
    
        while True:
            # Wait for a connection
            print("Waiting for a client to connect...")
            client_socket, client_address = server_socket.accept()
            print("Connected to client:", client_address)
    
            while True:
                # Receive data from the client
                message = client_socket.recv(1024)
                if not message:
                    break
    
                # Convert the received message to uppercase
                response = message.decode().upper()
    
                # Send the response back to the client
                if random.randint(0,11) >= 4:
                    client_socket.sendall(response.encode())

    except Exception as e:
        print("Error:", e)
    finally:
        # Clean up the connection
        client_socket.close()
    

    
def main():
    start_server(hostname='172.31.0.3',port_number=5001)

if __name__ == "__main__":
    main()

