import random
import socket


def start_server(hostname,port_number):

    # Create a UDP socket
    server_socket = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

    # Bind the socket to a specific address and port
    server_socket.bind((hostname,port_number))
    print('server started')

    while True:

        # Receive data from the client
        message, address = server_socket.recvfrom(1024)

        # Send the response back to the client
        if random.randint(0,11) >= 4:
            print('message recieved')
            message=message.decode()
            print(message)
             # Convert the received message to uppercase
            message = message.upper()
            server_socket.sendto(message.encode(), address)


def main():
    start_server(hostname='172.31.0.3',port_number=5001)


if __name__ == "__main__":
    main()

                       
