import socket
import time




def connect_to_server(destination_ip,destination_port):
    # Create a TCP socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Wait for packet for 1 sec only
    #client_socket.settimeout(5.0)
    server_address = (destination_ip, destination_port)
    try:
        client_socket.connect(server_address)
        print('Connected to server: ')

        build_packets(client_socket)
    except:
        print('connection refused')


    # List to store a tuple of packet number and it's RTT
    
def build_packets(client_socket):

    #client_socket.settimeout(5.0)
    client_socket.settimeout(1.0)
    list_of_time=[]
    #count numberof retransmitted packet
    cnt=0

    try:
        # Take input from user of number of packets
        n = int(input("Enter the number of packets to send: "))
        send_packets(client_socket,list_of_time,n,cnt)
        #print(list_of_time)
        list_of_rtt=[i[1] for i in list_of_time]
        print('Maximum RTT is: '+str(max(list_of_rtt)))
        print('Minimum RTT is: '+str(min(list_of_rtt)))
        print('Avg of RRT is: '+str(sum(list_of_rtt)/n))

        client_socket.close()
    except:
         print('Invalide Input')



def send_packets(client_socket,list_of_time,n,cnt):

        for i in range(n):
            
            while True:
                # Store the time before sending
                start_time = time.time()
                # Message formate is 'ping sequence_number time stemp'
                message='ping '+str(i+1)+' '+str(start_time)
                # Send the message to the server
                client_socket.sendall(message.encode())
                # Receive the response from the server
    
                # If you got response within 1 sec else it will go into except
                try:
                    response = client_socket.recv(1024)
                    break
                except:
                    cnt+=1
                    print('retransmitted packet '+ str(i+1))
                    
            # Store the time after reply
            end_time =time.time()
            list_of_time.append((i+1,end_time-start_time))
            print("Server response:", response.decode())
        
        print('Number of time packet retransmitteda and loss ' +str(cnt)+' '+str((cnt/n)*100) + str('%'))




def main():
    connect_to_server(destination_ip='172.31.0.3',destination_port=5001)


if __name__ == "__main__":
    main()
